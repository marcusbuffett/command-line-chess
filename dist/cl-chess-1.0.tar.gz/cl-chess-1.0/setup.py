from distutils.core import setup
setup(
  name = 'cl-chess',
  packages = ['cl-chess'], # this must be the same as the name above
  version = '1.0',
  description = 'A program to play chess on the command line',
  author = 'Marcus Buffett',
  author_email = 'marcusbuffett@me.com',
  url = 'https://github.com/marcusbuffett/command-line-chess', # use the URL to the github repo
  download_url = 'https://github.com/peterldowns/mypackage/tarball/0.1', # I'll explain this in a second
  keywords = ['chess', 'game'], # arbitrary keywords
  classifiers = [],
)
